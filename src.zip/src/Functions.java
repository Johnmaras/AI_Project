import java.io.*;

/**
 * Created by John on 4/12/2016.
 */
public class Functions {


    public static CNFClause readFile(String filename){
        CNFClause KB = new CNFClause();
        String lname;
        boolean lneg;

        try{
            String line;
            File f;
            BufferedReader reader;
            f = new File(filename);
            reader = new BufferedReader(new FileReader(f));
            line = reader.readLine();
            boolean entered = false;
            while(line != null){
                CNFSubClause newSub = new CNFSubClause();
                while(line != null && !isEmpty(line)){
                    Literal newliteral = new Literal();
                    entered = true;
                    lname = line.trim().substring(0, line.indexOf(' '));
                    line = line.trim().substring(line.indexOf(' '));
                    lneg = Boolean.parseBoolean(line.trim());
                    newliteral.setName(lname);
                    newliteral.setNeg(lneg);
                    newSub.getLiterals().add(new Literal(newliteral));
                    line = reader.readLine();
                }
                line = reader.readLine();
                if(entered)
                    KB.getSubclauses().add(newSub);
                entered = false;
            }
            return KB;
        }catch(NullPointerException e){
            System.err.println("File not found");
        }catch(FileNotFoundException e){
            System.err.println("Error opening file");
        }catch (IOException e){
            System.out.println("Line : Sudden end.");
        }

        return null;
    }

    public static boolean checkFile(String filename){
        try{
            File f = new File(filename);
            BufferedReader reader = new BufferedReader(new FileReader(f));
            String line = reader.readLine();
            return true;
        }catch(NullPointerException e){
            System.err.println("File not found");
        }catch(FileNotFoundException e){
            System.err.println("Error opening file");
        }catch (IOException e){
            System.out.println("Line : Sudden end.");
        }

        return false;
    }

    private static boolean isEmpty(String line){
        return line.equals("") || line.trim().charAt(0) == ' ' || line.trim().charAt(0) == '#';
    }













}
